/* ============================================================
   script.js — El Valor de la Toma de Decisiones Financieras
   Presentación académica interactiva
   ============================================================ */

'use strict';

/* ============================================================
   CONFIGURACIÓN DE FONDOS POR ETAPA
   ============================================================ */
const ERA_CONFIG = {
  origen:     { overlay: 'rgba(5, 30, 12, .58)',  label: 'El Contador como Pilar' },
  impacto:    { overlay: 'rgba(5, 20, 40, .60)',  label: 'Impacto en Decisiones' },
  etica:      { overlay: 'rgba(35, 8, 55, .60)',  label: 'Ética Contable' },
  digital:    { overlay: 'rgba(5, 18, 38, .62)',  label: 'Revolución Digital' },
  estrategia: { overlay: 'rgba(40, 15, 5, .60)',  label: 'Interpretación Estratégica' },
  gestion:    { overlay: 'rgba(15, 12, 45, .60)', label: 'Gestión Conjunta' }
};

/* ============================================================
   INICIALIZACIÓN
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  AOS.init({ duration: 750, easing: 'ease-out-cubic', once: true, offset: 70 });

  buildSceneLayers();
  initParticles();
  initNavbar();
  initNavToggle();
  initBtnTop();
  initTimelineGrowLine();
  initMapaTooltips();
  initSmoothScroll();
  initTimelineBackground();
});

/* ============================================================
   1. CONSTRUIR CAPAS DE FONDO
   ============================================================ */
function buildSceneLayers() {
  const sceneBg = document.getElementById('scene-bg');
  if (!sceneBg) return;

  document.querySelectorAll('.timeline-item[data-bg]').forEach((item, i) => {
    const layer = document.createElement('div');
    layer.className = 'scene-layer';
    layer.style.backgroundImage = `url('${item.dataset.bg}')`;
    sceneBg.appendChild(layer);
    item.dataset.layerIndex = i;
  });
}

/* ============================================================
   2. FONDO DINÁMICO — desactivado (línea del tiempo compacta sin scroll)
   ============================================================ */
function initTimelineBackground() {
  // No se usa con la línea del tiempo compacta
}

/* ============================================================
   3. PARTÍCULAS EN CANVAS
   ============================================================ */
class Particle {
  constructor(w, h) { this.reset(w, h); }

  reset(w, h) {
    this.x     = Math.random() * w;
    this.y     = Math.random() * h;
    this.vx    = (Math.random() - 0.5) * 0.55;
    this.vy    = (Math.random() - 0.5) * 0.55;
    this.radio = Math.random() * 2.2 + 0.7;
    this.color = Math.random() > 0.5
      ? `rgba(74,222,128,${(Math.random() * 0.5 + 0.2).toFixed(2)})`
      : `rgba(56,189,248,${(Math.random() * 0.4 + 0.15).toFixed(2)})`;
  }

  update(w, h) {
    this.x += this.vx;
    this.y += this.vy;
    if (this.x < 0 || this.x > w) this.vx *= -1;
    if (this.y < 0 || this.y > h) this.vy *= -1;
  }

  draw(ctx) {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radio, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.fill();
  }
}

function initParticles() {
  const canvas = document.getElementById('particles');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  let particles = [];
  const NUM = 100;

  function resize() {
    canvas.width  = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
  }

  function create() {
    particles = Array.from({ length: NUM }, () => new Particle(canvas.width, canvas.height));
  }

  function drawConnections() {
    const MAX = 115;
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const d  = Math.sqrt(dx * dx + dy * dy);
        if (d < MAX) {
          const a = (1 - d / MAX) * 0.2;
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = `rgba(74,222,128,${a.toFixed(3)})`;
          ctx.lineWidth = 0.7;
          ctx.stroke();
        }
      }
    }
  }

  function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawConnections();
    particles.forEach(p => { p.update(canvas.width, canvas.height); p.draw(ctx); });
    requestAnimationFrame(animate);
  }

  resize(); create(); animate();
  window.addEventListener('resize', () => { resize(); create(); });
}

/* ============================================================
   4. NAVBAR
   ============================================================ */
function initNavbar() {
  const navbar   = document.getElementById('navbar');
  const navLinks = document.querySelectorAll('.nav-link');

  window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 50);
  }, { passive: true });

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const id = entry.target.getAttribute('id');
          navLinks.forEach(link => {
            link.classList.toggle('active', link.getAttribute('href') === `#${id}`);
          });
        }
      });
    },
    { rootMargin: '-40% 0px -55% 0px', threshold: 0 }
  );

  document.querySelectorAll('section[id]').forEach(sec => observer.observe(sec));
}

/* ============================================================
   5. NAVBAR TOGGLE
   ============================================================ */
function initNavToggle() {
  const toggle = document.getElementById('navToggle');
  const links  = document.querySelector('.nav-links');
  if (!toggle || !links) return;

  toggle.addEventListener('click', () => {
    links.classList.toggle('open');
    toggle.setAttribute('aria-expanded', links.classList.contains('open'));
  });

  links.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => links.classList.remove('open'));
  });
}

/* ============================================================
   6. BOTÓN VOLVER ARRIBA
   ============================================================ */
function initBtnTop() {
  const btn = document.getElementById('btn-top');
  if (!btn) return;
  window.addEventListener('scroll', () => btn.classList.toggle('visible', window.scrollY > 300), { passive: true });
  btn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
}

/* ============================================================
   7. SCROLL SUAVE
   ============================================================ */
function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', (e) => {
      const id = anchor.getAttribute('href');
      if (id === '#') return;
      const target = document.querySelector(id);
      if (!target) return;
      e.preventDefault();
      const navH = document.getElementById('navbar')?.offsetHeight || 70;
      window.scrollTo({ top: target.getBoundingClientRect().top + window.scrollY - navH, behavior: 'smooth' });
    });
  });
}

/* ============================================================
   8. LÍNEA DEL TIEMPO — desactivado (compacta sin scroll)
   ============================================================ */
function initTimelineGrowLine() {
  // No se usa con la línea del tiempo compacta
}

/* ============================================================
   9. MAPA CONCEPTUAL — tooltips
   ============================================================ */
function initMapaTooltips() {
  const svgEl   = document.getElementById('mapa-svg');
  const tooltip = document.getElementById('mapa-tooltip');
  if (!svgEl || !tooltip) return;

  svgEl.querySelectorAll('.mapa-nodo').forEach(nodo => {
    const texto = nodo.dataset.tooltip || '';

    function show(e) { tooltip.textContent = texto; tooltip.classList.add('visible'); position(e); }
    function hide()  { tooltip.classList.remove('visible'); }

    function position(e) {
      const wrapper = svgEl.closest('.mapa-wrapper');
      if (!wrapper) return;
      const rect = wrapper.getBoundingClientRect();
      let x = e.clientX - rect.left + 14;
      let y = e.clientY - rect.top  - 10;
      const tipW = tooltip.offsetWidth || 270;
      if (x + tipW > wrapper.offsetWidth) x = e.clientX - rect.left - tipW - 14;
      tooltip.style.left = `${x}px`;
      tooltip.style.top  = `${y}px`;
    }

    nodo.addEventListener('mouseenter', show);
    nodo.addEventListener('mousemove',  position);
    nodo.addEventListener('mouseleave', hide);

    nodo.addEventListener('focus', () => {
      tooltip.textContent = texto;
      tooltip.classList.add('visible');
      const wrapper = svgEl.closest('.mapa-wrapper');
      if (!wrapper) return;
      const wRect = wrapper.getBoundingClientRect();
      const nRect = nodo.getBoundingClientRect();
      tooltip.style.left = `${nRect.left - wRect.left}px`;
      tooltip.style.top  = `${nRect.bottom - wRect.top + 8}px`;
    });

    nodo.addEventListener('blur', hide);
  });

  svgEl.addEventListener('mouseleave', () => tooltip.classList.remove('visible'));
}

/* ============================================================
   10. ANIMACIÓN DE ENTRADA DE TARJETAS
   ============================================================ */
(function observeTimelineCards() {
  const cards = document.querySelectorAll('.timeline-card');
  if (!cards.length) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity   = '1';
          entry.target.style.transform = 'translateY(0)';
        }
      });
    },
    { threshold: 0.1 }
  );

  cards.forEach(card => {
    if (!card.closest('[data-aos]')) {
      card.style.opacity    = '0';
      card.style.transform  = 'translateY(28px)';
      card.style.transition = 'opacity .6s ease, transform .6s ease';
    }
    observer.observe(card);
  });
})();

/* ============================================================
   FIN DEL SCRIPT
   ============================================================ */
